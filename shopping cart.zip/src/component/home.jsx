import React from "react";
import { useEffect, useState } from "react";
import axios from "axios";
import {useDispatch} from 'react-redux'
import{addToCart} from '../features/cartSlice'
import{useNavigate}from 'react-router-dom'

const Home = () => {
  const [fetchdata, setFetchData] = useState([]);
  
const dispatch= useDispatch();
const router=useNavigate();
  useEffect(() => {
    try {
      const data = async () => {
        const apidata = await axios.get("https://fakestoreapi.com/products");
        let res = await apidata.data;
        setFetchData(res);
      };
      data();
    } catch (error) {
      console.log(error);
    }
  }, []);

const handleAddToCart=(fetching)=>{
  dispatch(addToCart(fetching));
  router("/cart");
  
}

  return (
    <>
      <h1 className="text-danger text-center">Online Shop </h1>
      <div className="container mt-5">
        <div className="row">
          {fetchdata.map((items,index) => {
            return (
              <>
                <div className="shadow p-5 col-lg-4"key={index}>
                  <h4>{items.id}</h4>
                  <h4>
                    <img src={items.image} width={200} height={200} alt="CAR"  />
                  </h4>
                  <h4 className="text-danger">Title:{items.title}</h4>
                  <h4 className="text-info">Price:${items.price}</h4>
                  <span className="text-primary"onClick={()=>handleAddToCart(items)}>Add to cart</span>
                </div>
              </>
            );
          })}
        </div>
      </div>
    </>
  );
};

export default Home;
